#include "tm1637.h"

const uint8_t SEGMENT_MAP[] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};

static void tm1637_delay(void) {
    sleep_us(5);
}

void tm1637_init(tm1637_t *disp, uint8_t clk, uint8_t dio) {
    disp->clk_pin = clk;
    disp->dio_pin = dio;
    disp->brightness = 7;
    
    gpio_init(clk);
    gpio_init(dio);
    gpio_set_dir(clk, GPIO_OUT);
    gpio_set_dir(dio, GPIO_OUT);
    gpio_put(clk, 1);
    gpio_put(dio, 1);
}

void tm1637_start(tm1637_t *disp) {
    gpio_set_dir(disp->dio_pin, GPIO_OUT);
    tm1637_delay();
    gpio_put(disp->clk_pin, 1);
    gpio_put(disp->dio_pin, 1);
    tm1637_delay();
    gpio_put(disp->dio_pin, 0);
    tm1637_delay();
    gpio_put(disp->clk_pin, 0);
}

void tm1637_stop(tm1637_t *disp) {
    gpio_set_dir(disp->dio_pin, GPIO_OUT);
    tm1637_delay();
    gpio_put(disp->clk_pin, 0);
    gpio_put(disp->dio_pin, 0);
    tm1637_delay();
    gpio_put(disp->clk_pin, 1);
    tm1637_delay();
    gpio_put(disp->dio_pin, 1);
}

void tm1637_write_byte(tm1637_t *disp, uint8_t data) {
    gpio_set_dir(disp->dio_pin, GPIO_OUT);
    
    for (int i = 0; i < 8; i++) {
        gpio_put(disp->clk_pin, 0);
        tm1637_delay();
        gpio_put(disp->dio_pin, (data & 0x01));
        tm1637_delay();
        gpio_put(disp->clk_pin, 1);
        tm1637_delay();
        data >>= 1;
    }
    
    gpio_set_dir(disp->dio_pin, GPIO_IN);
    gpio_put(disp->clk_pin, 0);
    tm1637_delay();
    gpio_put(disp->clk_pin, 1);
    tm1637_delay();
    gpio_set_dir(disp->dio_pin, GPIO_OUT);
}

void tm1637_display_segments(tm1637_t *disp, const uint8_t *segments) {
    tm1637_start(disp);
    tm1637_write_byte(disp, TM1637_ADDR_AUTO);
    tm1637_stop(disp);
    
    tm1637_start(disp);
    tm1637_write_byte(disp, 0xC0);
    
    for (int i = 0; i < 4; i++) {
        tm1637_write_byte(disp, segments[i]);
    }
    
    tm1637_stop(disp);
    
    tm1637_start(disp);
    tm1637_write_byte(disp, TM1637_CMD_DISPLAY | (disp->brightness & 0x07));
    tm1637_stop(disp);
}

void tm1637_display_number(tm1637_t *disp, int16_t number) {
    uint8_t segments[4] = {0};
    
    if (number < 0) number = 0;
    if (number > 9999) number = 9999;
    
    segments[3] = SEGMENT_MAP[number % 10];
    if (number >= 10) segments[2] = SEGMENT_MAP[(number / 10) % 10];
    if (number >= 100) segments[1] = SEGMENT_MAP[(number / 100) % 10];
    if (number >= 1000) segments[0] = SEGMENT_MAP[number / 1000];
    
    tm1637_display_segments(disp, segments);
}

void tm1637_set_brightness(tm1637_t *disp, uint8_t brightness) {
    disp->brightness = brightness & 0x07;
}

void tm1637_display_on(tm1637_t *disp) {
    uint8_t segments[4] = {0};
    tm1637_display_segments(disp, segments);
}

void tm1637_display_off(tm1637_t *disp) {
    uint8_t segments[4] = {0};
    tm1637_display_segments(disp, segments);
}