// Incluye el archivo de cabecera personalizado "semaforo.h", que probablemente contiene
// definiciones de pines, constantes de tiempo y tipos enumerados.
#include "semaforo.h"
// Incluye la biblioteca estándar de entrada/salida para usar printf.
#include <stdio.h>

// Variable global volátil que almacena el estado actual del sistema (máquina de estados).
// Se inicializa en modo vehicular automático.
volatile system_state_t current_state = STATE_VEHICULAR_AUTO;

// Color actual del semáforo vehicular 1 (V1): 0=Verde, 1=Amarillo, 2=Rojo.
volatile int v1_color = 0;
// Color actual del semáforo vehicular 2 (V2): 0=Verde, 1=Amarillo, 2=Rojo.
volatile int v2_color = 2;
// Temporizador restante para el estado actual del semáforo V1. Inicializado en tiempo de verde.
volatile int v1_timer = TIME_GREEN;
// Temporizador restante para el estado actual del semáforo V2. Inicializado en tiempo de rojo.
volatile int v2_timer = TIME_RED;

// Bandera que indica si se ha solicitado el cruce peatonal 1 (activa por botón).
volatile bool pedestrian1_request = false;
// Bandera que indica si se ha solicitado el cruce peatonal 2.
volatile bool pedestrian2_request = false;
// Contador regresivo para el tiempo restante de cruce del peatón 1.
volatile int  pedestrian1_counter = 0;
// Contador regresivo para el tiempo restante de cruce del peatón 2.
volatile int  pedestrian2_counter = 0;
// Indica si el cruce peatonal 1 está actualmente activo (luz verde peatonal encendida).
volatile bool pedestrian1_active  = false;
// Indica si el cruce peatonal 2 está activo.
volatile bool pedestrian2_active  = false;

// Duración restante de la señal acústica (buzzer) en ticks (cada tick = 5ms).
volatile int  buzzer_ticks  = 0;
// Bandera que indica si el buzzer está emitiendo sonido.
volatile bool buzzer_active = false;

// Mapa de segmentos para un display de 7 segmentos (ánodo común o cátodo común, según lógica).
// Cada byte representa qué segmentos encender para los dígitos 0-9. Por ejemplo, 0 = 0b00111111.
const uint8_t segment_map[10] = {
    0b00111111, 0b00000110, 0b01011011, 0b01001111, 0b01100110,
    0b01101101, 0b01111101, 0b00000111, 0b01111111, 0b01101111
};
// Array con los números de pin GPIO correspondientes a cada segmento (A, B, C, D, E, F, G).
const uint8_t segment_pins[7] = {SEG_A, SEG_B, SEG_C, SEG_D, SEG_E, SEG_F, SEG_G};
// Array con los pines de habilitación de cada dígito del display (2 displays, decenas y unidades para P1 y P2).
const uint8_t display_pins[4] = {DISP1_DEC, DISP1_UNI, DISP2_DEC, DISP2_UNI};
// Índice del dígito del display que se está multiplexando actualmente (0 a 3).
volatile int  current_display   = 0;
// Array que almacena los valores numéricos (0-9) a mostrar en cada uno de los 4 dígitos.
volatile int  display_values[4] = {0, 0, 0, 0};
// Array de banderas que indica si cada uno de los 4 dígitos debe estar encendido o apagado.
volatile bool displays_on[4]    = {false, false, false, false};

// Función de inicialización del hardware (GPIO, PWM, etc.)
void init_hardware(void) {
    // Inicializa el pin para LED Rojo de V1 y lo configura como salida.
    gpio_init(V1_RED);    gpio_set_dir(V1_RED,    GPIO_OUT);
    // Inicializa pin Amarillo V1 como salida.
    gpio_init(V1_YELLOW); gpio_set_dir(V1_YELLOW, GPIO_OUT);
    // Inicializa pin Verde V1 como salida.
    gpio_init(V1_GREEN);  gpio_set_dir(V1_GREEN,  GPIO_OUT);
    // Inicializa pin Rojo V2 como salida.
    gpio_init(V2_RED);    gpio_set_dir(V2_RED,    GPIO_OUT);
    // Inicializa pin Amarillo V2 como salida.
    gpio_init(V2_YELLOW); gpio_set_dir(V2_YELLOW, GPIO_OUT);
    // Inicializa pin Verde V2 como salida.
    gpio_init(V2_GREEN);  gpio_set_dir(V2_GREEN,  GPIO_OUT);
    // Inicializa pin Rojo peatonal 1 como salida.
    gpio_init(P1_RED);    gpio_set_dir(P1_RED,    GPIO_OUT);
    // Inicializa pin Verde peatonal 1 como salida.
    gpio_init(P1_GREEN);  gpio_set_dir(P1_GREEN,  GPIO_OUT);
    // Inicializa pin Rojo peatonal 2 como salida.
    gpio_init(P2_RED);    gpio_set_dir(P2_RED,    GPIO_OUT);
    // Inicializa pin Verde peatonal 2 como salida.
    gpio_init(P2_GREEN);  gpio_set_dir(P2_GREEN,  GPIO_OUT);

    // Bucle para inicializar los 7 pines de segmentos del display.
    for (int i = 0; i < 7; i++) {
        gpio_init(segment_pins[i]);                    // Inicializa el pin GPIO.
        gpio_set_dir(segment_pins[i], GPIO_OUT);       // Lo configura como salida.
        gpio_put(segment_pins[i], 0);                  // Apaga el segmento (inicializa en bajo).
    }
    // Bucle para inicializar los 4 pines de habilitación de dígitos.
    for (int i = 0; i < 4; i++) {
        gpio_init(display_pins[i]);                    // Inicializa el pin GPIO.
        gpio_set_dir(display_pins[i], GPIO_OUT);       // Lo configura como salida.
        gpio_put(display_pins[i], 1);                  // Apaga el dígito (asume lógica de cátodo común con transistor PNP o similar, HIGH=off).
    }

    // Inicializa el pin del botón 1 como entrada con resistencia pull-up interna.
    gpio_init(BUTTON1); gpio_set_dir(BUTTON1, GPIO_IN); gpio_pull_up(BUTTON1);
    // Inicializa pin botón 2 como entrada con pull-up.
    gpio_init(BUTTON2); gpio_set_dir(BUTTON2, GPIO_IN); gpio_pull_up(BUTTON2);

    // Configura el pin del buzzer para funcionar como salida PWM.
    gpio_set_function(BUZZER, GPIO_FUNC_PWM);
    // Obtiene el canal PWM asociado al pin del buzzer.
    uint slice = pwm_gpio_to_slice_num(BUZZER);
    // Establece el valor máximo del contador PWM (wrap value) a 1000, definiendo la resolución.
    pwm_set_wrap(slice, 1000);
    // Ajusta el ciclo de trabajo del PWM al 0% (silencio inicial).
    pwm_set_chan_level(slice, pwm_gpio_to_channel(BUZZER), 0);
    // Habilita la salida PWM para este slice.
    pwm_set_enabled(slice, true);

    // Actualiza todas las luces (LEDs) al estado inicial definido por las variables globales.
    update_all_lights();
    // Imprime mensaje de inicio del sistema por el puerto serie.
    printf("=== SISTEMA INICIADO: V1=Verde V2=Rojo ===\n");
}

// Función para activar el buzzer durante un tiempo determinado.
void buzzer_trigger(int duracion_ms) {
    // Convierte la duración en milisegundos a número de ticks (asumiendo 5ms por tick).
    buzzer_ticks  = duracion_ms / 5;
    // Activa la bandera del buzzer.
    buzzer_active = true;
    // Obtiene el slice PWM para el buzzer.
    uint slice = pwm_gpio_to_slice_num(BUZZER);
    // Ajusta el ciclo de trabajo del PWM al 50% (500 de 1000) para generar tono.
    pwm_set_chan_level(slice, pwm_gpio_to_channel(BUZZER), 500);
}

// Función llamada periódicamente (cada 5ms) para gestionar la duración del buzzer.
void buzzer_tick(void) {
    // Si el buzzer no está activo, sale de la función.
    if (!buzzer_active) return;
    // Si todavía quedan ticks, los decrementa.
    if (buzzer_ticks > 0) {
        buzzer_ticks--;
    } else {
        // Si los ticks llegaron a 0, desactiva el buzzer.
        buzzer_active = false;
        uint slice = pwm_gpio_to_slice_num(BUZZER);
        // Apaga el sonido poniendo el ciclo de trabajo a 0.
        pwm_set_chan_level(slice, pwm_gpio_to_channel(BUZZER), 0);
    }
}

// Función placeholder para emitir múltiples beeps (actualmente solo hace uno usando buzzer_trigger).
void buzzer_beep(int ms, int times) {
    buzzer_trigger(ms); // Ignora 'times', solo emite un beep simple.
}

// Actualiza el estado de todos los pines GPIO conectados a los LEDs según las variables de color y actividad.
void update_all_lights(void) {
    // Enciende LED Verde V1 si v1_color es 0; sino lo apaga.
    gpio_put(V1_GREEN,  v1_color == 0 ? 1 : 0);
    // Enciende LED Amarillo V1 si v1_color es 1.
    gpio_put(V1_YELLOW, v1_color == 1 ? 1 : 0);
    // Enciende LED Rojo V1 si v1_color es 2.
    gpio_put(V1_RED,    v1_color == 2 ? 1 : 0);
    // Enciende LED Verde V2 si v2_color es 0.
    gpio_put(V2_GREEN,  v2_color == 0 ? 1 : 0);
    // Enciende LED Amarillo V2 si v2_color es 1.
    gpio_put(V2_YELLOW, v2_color == 1 ? 1 : 0);
    // Enciende LED Rojo V2 si v2_color es 2.
    gpio_put(V2_RED,    v2_color == 2 ? 1 : 0);
    // Enciende LED Verde peatonal 1 solo si pedestrian1_active es true.
    gpio_put(P1_GREEN,  pedestrian1_active ? 1 : 0);
    // Enciende LED Rojo peatonal 1 solo si pedestrian1_active es false (lógica inversa).
    gpio_put(P1_RED,    pedestrian1_active ? 0 : 1);
    // Enciende LED Verde peatonal 2 solo si pedestrian2_active es true.
    gpio_put(P2_GREEN,  pedestrian2_active ? 1 : 0);
    // Enciende LED Rojo peatonal 2 solo si pedestrian2_active es false.
    gpio_put(P2_RED,    pedestrian2_active ? 0 : 1);
}

// Prepara los valores del display de 7 segmentos para mostrar los contadores peatonales.
void update_displays(void) {
    // Si el cruce peatonal 1 está activo...
    if (pedestrian1_active) {
        // El dígito de decenas (índice 0) se enciende solo si el contador es >= 10.
        displays_on[0]    = (pedestrian1_counter >= 10);
        // El dígito de unidades (índice 1) siempre se enciende.
        displays_on[1]    = true;
        // Calcula la decena del contador y la almacena.
        display_values[0] = pedestrian1_counter / 10;
        // Calcula la unidad del contador y la almacena.
        display_values[1] = pedestrian1_counter % 10;
    } else {
        // Si no está activo, apaga ambos dígitos del display 1.
        displays_on[0] = displays_on[1] = false;
    }
    // Repite la misma lógica para el cruce peatonal 2.
    if (pedestrian2_active) {
        // Decenas de P2 (índice 2).
        displays_on[2]    = (pedestrian2_counter >= 10);
        // Unidades de P2 (índice 3).
        displays_on[3]    = true;
        display_values[2] = pedestrian2_counter / 10;
        display_values[3] = pedestrian2_counter % 10;
    } else {
        displays_on[2] = displays_on[3] = false;
    }
}

// Función llamada periódicamente (muy rápido, mediante timer/interrupción) para multiplexar los displays de 7 segmentos.
void multiplex_display(void) {
    // Primero, maneja el tick del buzzer (decrementa tiempo si está activo).
    buzzer_tick();

    // Apaga todos los dígitos (pone el pin de habilitación en estado inactivo) para evitar efecto fantasma.
    for (int i = 0; i < 4; i++) gpio_put(display_pins[i], 1);
    // Apaga todos los segmentos del dígito actual.
    for (int i = 0; i < 7; i++) gpio_put(segment_pins[i], 0);

    // Si el dígito actual (según current_display) debe estar encendido...
    if (displays_on[current_display]) {
        // Obtiene la máscara de segmentos para el valor almacenado en este dígito.
        uint8_t seg = segment_map[display_values[current_display]];
        // Recorre los 7 segmentos y establece cada pin GPIO según el bit correspondiente de la máscara.
        for (int i = 0; i < 7; i++)
            gpio_put(segment_pins[i], (seg >> i) & 0x01);
        // Habilita (enciende) este dígito poniendo su pin de selección en activo (LOW, según lógica).
        gpio_put(display_pins[current_display], 0);
    }
    // Avanza al siguiente dígito para la próxima llamada a esta función (round-robin 0-1-2-3).
    current_display = (current_display + 1) % 4;
}

// Función estática (local al archivo) que maneja el temporizador y cambios de los semáforos vehiculares.
static void tick_vehicular(void) {
    // Decrementa el temporizador de V1 si es mayor que 0.
    if (v1_timer > 0) v1_timer--;
    // Decrementa el temporizador de V2 si es mayor que 0.
    if (v2_timer > 0) v2_timer--;

    // Verifica si el temporizador de V1 ha expirado (llegó a 0 en este instante).
    if (v1_timer == 0) {
        // Si V1 estaba en verde, pasa a amarillo y carga el tiempo de amarillo.
        if (v1_color == 0) {
            v1_color = 1; v1_timer = TIME_YELLOW;
            printf("[V1] Verde -> Amarillo\n");
        } 
        // Si V1 estaba en amarillo, pasa a rojo, V2 a verde y carga tiempos correspondientes.
        else if (v1_color == 1) {
            v1_color = 2; v1_timer = TIME_RED;
            v2_color = 0; v2_timer = TIME_GREEN;
            printf("[V1] Amarillo -> Rojo | [V2] -> Verde\n");
        }
    }
    // Repite la misma lógica para la expiración del temporizador de V2.
    if (v2_timer == 0) {
        if (v2_color == 0) {
            v2_color = 1; v2_timer = TIME_YELLOW;
            printf("[V2] Verde -> Amarillo\n");
        } else if (v2_color == 1) {
            v2_color = 2; v2_timer = TIME_RED;
            v1_color = 0; v1_timer = TIME_GREEN;
            printf("[V2] Amarillo -> Rojo | [V1] -> Verde\n");
        }
    }
}

// Función principal de lógica del sistema. Maneja entradas (botones) y la máquina de estados.
void process_state_machine(void) {

    /* --- BOTONES --- */
    // Lee el botón 1: Si está presionado (LOW), no hay solicitud previa, y el cruce no está activo, registra solicitud.
    if (!gpio_get(BUTTON1) && !pedestrian1_request && !pedestrian1_active) {
        pedestrian1_request = true;
        printf("[BTN1] Solicitud registrada\n");
    }
    // Lee el botón 2 con la misma lógica.
    if (!gpio_get(BUTTON2) && !pedestrian2_request && !pedestrian2_active) {
        pedestrian2_request = true;
        printf("[BTN2] Solicitud registrada\n");
    }

    /* ---- STATE_VEHICULAR_AUTO ---- */
    if (current_state == STATE_VEHICULAR_AUTO) {

        // Avanza los temporizadores vehiculares.
        tick_vehicular();

        // Si hay solicitud peatonal 1...
        if (pedestrian1_request) {
            // Verifica si V1 ya está en rojo.
            if (v1_color == 2) {
                printf("[P1] V1 ya en rojo -> Cruce ACTIVO\n");
                // Activa cruce peatonal 1 inmediatamente.
                pedestrian1_active  = true;
                pedestrian1_counter = TIME_PEDESTRIAN; // Carga el tiempo de cruce.
                pedestrian1_request = false;           // Borra la solicitud.
                v2_color = 0; v2_timer = TIME_PEDESTRIAN + 1; // Pone V2 en verde y ajusta su temporizador.
                current_state = STATE_P1_ACTIVE;      // Cambia al estado de cruce activo.
                buzzer_trigger(200);                  // Emite beep de inicio.
            } else {
                // Si V1 no está en rojo, hay que esperar. Imprime estado actual e inicia espera.
                printf("[P1] Esperando rojo en V1 (actual=%s)\n",
                    v1_color == 0 ? "Verde" : "Amarillo");
                current_state = STATE_WAIT_V1_RED;
            }
        }
        // Si hay solicitud peatonal 2, lógica simétrica a la de arriba.
        else if (pedestrian2_request) {
            if (v2_color == 2) {
                printf("[P2] V2 ya en rojo -> Cruce ACTIVO\n");
                pedestrian2_active  = true;
                pedestrian2_counter = TIME_PEDESTRIAN;
                pedestrian2_request = false;
                v1_color = 0; v1_timer = TIME_PEDESTRIAN + 1;
                current_state = STATE_P2_ACTIVE;
                buzzer_trigger(200);
            } else {
                printf("[P2] Esperando rojo en V2 (actual=%s)\n",
                    v2_color == 0 ? "Verde" : "Amarillo");
                current_state = STATE_WAIT_V2_RED;
            }
        }

    /* ---- STATE_WAIT_V1_RED ---- */
    } else if (current_state == STATE_WAIT_V1_RED) {

        // Guarda el color de V1 antes de ejecutar el tick para detectar transiciones.
        int prev = v1_color;
        tick_vehicular(); // Avanza la temporización vehicular.

        printf("[WAIT_V1] V1=%s timer=%d\n",
            v1_color==0?"Verde":v1_color==1?"Amarillo":"Rojo", v1_timer);

        /* Activar solo cuando V1 CAMBIA a rojo en este tick. 
           Verifica que antes no era rojo (prev != 2) y ahora sí lo es. */
        if (prev != 2 && v1_color == 2) {
            printf("[P1] V1 llego a rojo -> Cruce ACTIVO\n");
            pedestrian1_active  = true;
            pedestrian1_counter = TIME_PEDESTRIAN;
            pedestrian1_request = false;
            v2_color = 0; v2_timer = TIME_PEDESTRIAN + 1;
            current_state = STATE_P1_ACTIVE;
            buzzer_trigger(200);
        }

    /* ---- STATE_P1_ACTIVE ---- */
    } else if (current_state == STATE_P1_ACTIVE) {

        // Durante el cruce, fuerza V1 rojo y V2 verde.
        v1_color = 2;
        v2_color = 0;

        printf("[P1] Contador: %d\n", pedestrian1_counter);

        // Decrementa el contador peatonal si aún no ha llegado a 0.
        if (pedestrian1_counter > 0) {
            pedestrian1_counter--;
        } else {
            // Contador llegó a 0, finaliza el cruce.
            printf("[P1] Cruce terminado\n");
            pedestrian1_active = false;
            // Restablece el tráfico normal: V1 verde, V2 rojo.
            v1_color = 0; v1_timer = TIME_GREEN;
            v2_color = 2; v2_timer = TIME_RED;
            current_state = STATE_VEHICULAR_AUTO; // Vuelve al estado principal.
            buzzer_trigger(400);                 // Emite un beep más largo de fin.
        }

    /* ---- STATE_WAIT_V2_RED ---- */
    } else if (current_state == STATE_WAIT_V2_RED) {

        // Simétrico a STATE_WAIT_V1_RED pero para V2.
        int prev = v2_color;
        tick_vehicular();

        printf("[WAIT_V2] V2=%s timer=%d\n",
            v2_color==0?"Verde":v2_color==1?"Amarillo":"Rojo", v2_timer);

        if (prev != 2 && v2_color == 2) {
            printf("[P2] V2 llego a rojo -> Cruce ACTIVO\n");
            pedestrian2_active  = true;
            pedestrian2_counter = TIME_PEDESTRIAN;
            pedestrian2_request = false;
            v1_color = 0; v1_timer = TIME_PEDESTRIAN + 1;
            current_state = STATE_P2_ACTIVE;
            buzzer_trigger(200);
        }

    /* ---- STATE_P2_ACTIVE ---- */
    } else if (current_state == STATE_P2_ACTIVE) {

        // Simétrico a STATE_P1_ACTIVE.
        v2_color = 2;
        v1_color = 0;

        printf("[P2] Contador: %d\n", pedestrian2_counter);

        if (pedestrian2_counter > 0) {
            pedestrian2_counter--;
        } else {
            printf("[P2] Cruce terminado\n");
            pedestrian2_active = false;
            v1_color = 0; v1_timer = TIME_GREEN;
            v2_color = 2; v2_timer = TIME_RED;
            current_state = STATE_VEHICULAR_AUTO;
            buzzer_trigger(400);
        }
    }
    // Al final de la máquina de estados, actualiza las salidas: LEDs y displays.
    update_all_lights();
    update_displays();
}

// Funciones vacías (stubs), probablemente para cumplir con una interfaz o para desarrollo futuro.
// Callback de interrupción para los botones (no se usa, se hace sondeo en process_state_machine).
void button_callback(uint gpio, uint32_t events) {}
// Placeholder para una función de actualización de luces de tráfico (ya se hace en update_all_lights).
void update_traffic_lights(void)    {}
// Placeholder para actualización de luces peatonales.
void update_pedestrian_lights(void) {}
// Placeholder para verificación de botones (ya se hace en process_state_machine).
void check_buttons(void)            {}